﻿using System.Text.Json;

public class AzureDevOpsApiClient
{
    private readonly HttpClient _client;
    private readonly string _baseInstanceUrl; 
    public AzureDevOpsApiClient(string baseInstanceUrl)
    {
        _baseInstanceUrl = baseInstanceUrl.TrimEnd('/');
        _client = new HttpClient(new HttpClientHandler
        {
            UseDefaultCredentials = true // Windows Auth
        });
    }

    public async Task DownloadFolderFromRepoAsync(
        string collection,
        string project,
        string repository,
        string scopePath,
        string basePath = "output",
        string branch = "master")
    {
        //curl - u :your - pat - here "http://devops...../_apis/projects?api-version=7.0"
        string encodedScope = Uri.EscapeDataString(scopePath);
        string encodedCollection = Uri.EscapeDataString(collection);
        string encodedProject = Uri.EscapeDataString(project);
        string encodedRepo = Uri.EscapeDataString(repository);

        string url = $"{_baseInstanceUrl}/{encodedCollection}/{encodedProject}/_apis/git/repositories/{encodedRepo}/items" +
                     $"?scopePath={encodedScope}&recursionLevel=Full&versionDescriptor.version={branch}&includeContentMetadata=true&api-version=7.0";
        Console.WriteLine("Calling URL: " + url);
        var files = await FetchFileListAsync(url);

        int total = files.Count();
        foreach (var f in files)
        {
            if (f.TryGetProperty("isFolder", out var isFolder) && isFolder.GetBoolean()) total--;
        }
        int current = 0;

        foreach (var file in files)
        {
            if (file.TryGetProperty("isFolder", out var isFolder) && isFolder.GetBoolean())
                continue;
            if (!file.TryGetProperty("path", out var pathElement) ||
                !file.TryGetProperty("url", out var urlElement))
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("⚠️ Skipping item due to missing 'path' or 'url'. Full item:");
                Console.ResetColor();
                Console.WriteLine(file.ToString());
                continue;
            }

            var path = file.GetProperty("path").GetString()!;
            var urlPart = file.GetProperty("url").GetString()!;

            var content = await DownloadFileContentAsync(urlPart);
            await SaveFileAsync(basePath, path, content);

            current++;
            Console.WriteLine($"[{current}/{total}] Saved: {path}");
        }

        Console.WriteLine("✅ All files downloaded.");
    }

    private async Task<List<JsonElement>> FetchFileListAsync(string url)
    {
        var response = await _client.GetAsync(url);
        response.EnsureSuccessStatusCode();

        var json = await response.Content.ReadAsStringAsync();
        
        using var doc = JsonDocument.Parse(json);
        var files = doc.RootElement.GetProperty("value");
        //files will be dispose.
        return files.EnumerateArray()
                .Select(item => item.Clone())
                .ToList();
    }


    private async Task<string> DownloadFileContentAsync(string downloadUrl)
    {
        var response = await _client.GetAsync(downloadUrl + "&api-version=7.0");
        response.EnsureSuccessStatusCode();
        return await response.Content.ReadAsStringAsync();
    }

    private async Task SaveFileAsync(string basePath, string filePath, string content)
    {
        var relativePath = filePath.TrimStart('/').Replace('/', Path.DirectorySeparatorChar);
        var fullPath = Path.Combine(basePath, relativePath);
        var path = Path.GetDirectoryName(fullPath);
        if (!Path.Exists(path))
        {
            Directory.CreateDirectory(path);
        }

        await File.WriteAllTextAsync(fullPath, content);
    }
}
