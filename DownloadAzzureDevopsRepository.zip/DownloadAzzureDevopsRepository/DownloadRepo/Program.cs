﻿using System.IO;
using System.Text.Json;

class Program
{
    static async Task Main()
    {
        var collection = "collection or organisation name";
        var project = "project name";
        var repository = "repository name";
        var scopePath = "folder path to download";
        var basePath = "path to save";
        var devOpsClient = new AzureDevOpsApiClient("http://devops....url");

        await devOpsClient.DownloadFolderFromRepoAsync(collection, project,repository, scopePath, basePath);
    }
}
